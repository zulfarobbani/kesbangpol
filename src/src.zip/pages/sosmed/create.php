<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<fieldset>
    <form action="/sosmed/store" method="POST">
    
        <label for="">Nama Instagram : </label>
        <input type="text" name="instagram">
        <br>
        <label for="">Nama Facebook : </label>
        <input type="text" name="facebook">
        <br>
        <label for="">Nama Youtube : </label>
        <input type="text" name="youtube">
        <br>
        <label for="">Nama Twitter : </label>
        <input type="text" name="twitter">
        <br>
        <label for="">Nama Whatsapp : </label>
        <input type="text" name="whatsapp">
        <br>
        <label for="">Nama Telegram : </label>
        <input type="text" name="telegram">
        <br>
        <button type="submit">Submit</button>
    </form>
</body>
</html>