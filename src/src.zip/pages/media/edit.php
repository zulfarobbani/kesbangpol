<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<fieldset>
    <form action="/media/edit/<?= $idMedia ?>/update" method="POST">
    <input type="hidden" values="<?= $id_test?>"></input>
        <label for="">Path Media : </label>
        <input type="text" name="pathMedia" value="<?= $pathMedia ?>">
        <br>
        <label for=""> Entitas : </label>
       <input type="text" name="idEntity" id="desk" value="<?= $idEntity ?>">
        <br>
        <label for="">Penulis id : </label>
        <input type="text" name="idRelation" value="<?= $idRelation ?>">
        <br>
        <button type="submit">Submit</button>
    </form>
</body>
</html>